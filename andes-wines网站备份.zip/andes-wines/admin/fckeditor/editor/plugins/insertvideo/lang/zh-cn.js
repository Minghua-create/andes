﻿// JScript 文件

FCKLang.InsertMusic   = '插入FLV视频 凡诺网络' ;