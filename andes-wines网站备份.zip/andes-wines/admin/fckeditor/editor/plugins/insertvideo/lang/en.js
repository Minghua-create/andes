﻿// JScript 文件

FCKLang.InsertMusic   = 'Insert FLV video' ;
