﻿FCKLang['DlgRemoteUploadTitle']			= '保存远程图片' ;
FCKLang['DlgRemoteUploadBtn']			= '保存远程图片' ;
FCKLang['DlgRemoteUploadCurrFile']		= '当前文件' ;
FCKLang['DlgRemoteUploadTotal']			= '共有' ;
FCKLang['DlgRemoteUploadUnit']			= '个文件' ;
FCKLang['DlgRemoteUploadDownloaded']	= '已下载' ;
FCKLang['DlgRemoteUploadAnalysis']		= '正在分析中...' ;
FCKLang['DlgRemoteUploading']			= "文件正在上传处理中.请耐心等待...";